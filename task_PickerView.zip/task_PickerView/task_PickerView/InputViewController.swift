//
//  InputViewController.swift
//  task_PickerView
//
//  Created by Nakata chisato on 2020/06/16.
//  Copyright © 2020 Ajima. All rights reserved.
//

import Foundation
